import { monthsName,dayNumber, monthNumber,yearNumber,firstDay,lastDay } from "./variables.js";

// export class selectedMonthdetailes{
//     constructor(date){
//         let dateArray = date.split('/')
//         this.dayNumber = dateArray[0]
//         this.monthNumber = dateArray[1]
//         this.yearNumber = dateArray[2] 
//     }
// }

